* Execute o arquivo run.bat 
* Abra o navegador Web de sua prefer�ncia.
* Copie o link http://localhost:8080/swagger-ui.html e cole na barra de endere�os.
* Acesse a documenta��o da API
package com.javainuse.swaggertest;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import persistence.StorageBooks;

@RestController
@SpringBootApplication
public class BookApplication {
	

	@RequestMapping(value = "/book", method = RequestMethod.GET, produces = "application/json")
	public String getAllBooks() {
		Gson gson = new Gson();
		return gson.toJson(Application.storageBooks.getAllBoooks());
	}

	@RequestMapping(value = "/book/title/{title}", method = RequestMethod.GET, produces = "application/json")
	public String getAllBooksByTitle(@PathVariable("title") String title) {
		Gson gson = new Gson();
		return gson.toJson(Application.storageBooks.getBooksByTitle(title));
	}

	@RequestMapping(value = "/book/author/{author}", method = RequestMethod.GET, produces = "application/json")
	public String getAllBooksByAutor(@PathVariable("author") String autor) {
		Gson gson = new Gson();
		return gson.toJson(Application.storageBooks.getBooksByAutor(autor));
	}

	@RequestMapping(value = "/book/isbn/{isbn}", method = RequestMethod.GET, produces = "application/json")
	public String getAllBooksByISBN(@PathVariable("isbn") String isbn) {
		Gson gson = new Gson();
		return gson.toJson(Application.storageBooks.getBooksByISBN(isbn));
	}

	@RequestMapping(value = "/book/criticism/{isbn}", method = RequestMethod.GET)
	public String getCriticismByISBN(@PathVariable("isbn") String isbn) {
		return Application.storageBooks.getCriticasByISBN(isbn);
	}

	/*public static void main(String[] args) {
		storageBooks = new StorageBooks();
		SpringApplication.run(BookApplication.class, args);
	}*/
}

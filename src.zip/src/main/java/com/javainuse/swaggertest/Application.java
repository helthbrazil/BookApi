package com.javainuse.swaggertest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import persistence.StorageBooks;

@SpringBootApplication
public class Application {
	public static StorageBooks storageBooks;

	public static void main(String[] args) {
		storageBooks = new StorageBooks();
		SpringApplication.run(Application.class, args);
	}

}
